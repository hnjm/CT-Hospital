﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityAPI.Models
{
    public class ForgotPasswordModel
    {
        public string Email { get; set; }
    }
}
