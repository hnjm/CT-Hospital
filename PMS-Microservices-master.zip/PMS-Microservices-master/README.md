[UseCase.zip](https://github.com/ravitejab2/PMS-Microservices/files/9794365/UseCase.zip)
[FullstackProject_v2.pdf](https://github.com/ravitejab2/PMS-Microservices/files/9794367/FullstackProject_v2.pdf)
[SampleData.zip](https://github.com/ravitejab2/PMS-Microservices/files/10294155/SampleData.zip)
